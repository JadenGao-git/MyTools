// swift-tools-version: 6.0
import PackageDescription

let package = Package(
    name: "MyTools",
    platforms: [ .macOS(.v14) ],
    targets: [
        .executableTarget(
            name: "MyTools",
            path: "Sources/MyTools",
            linkerSettings: [
                .linkedFramework("CoreAudio"),
                .linkedFramework("IOBluetooth"),
                .linkedFramework("ServiceManagement")
            ]
        )
    ]
)
