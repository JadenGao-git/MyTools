# My Tools

A native macOS (SwiftUI) app that hosts a collection of small personal utilities.
Built as a **plugin architecture** so adding a new tool is a one-file job.

First built-in tool: **Bluetooth → Mic** — when a chosen Bluetooth device
connects, it snaps the system audio *input* back to your built-in microphone.

---

## Build & package

```bash
bash scripts/build_dmg.sh
```

Outputs:
- `build/My Tools.app`  — the app bundle (ad-hoc signed)
- `build/My Tools.dmg`  — drag-to-Applications installer

Dev iteration (just run, no packaging):

```bash
swift run --disable-sandbox
```

> `--disable-sandbox` is only needed because of this build environment; on a
> normal machine plain `swift run` / `swift build` works too.

---

## Project layout

```
Sources/MyTools/
  App/            App entry point + window shell (sidebar + detail pane)
  Core/           Tool protocol + ToolRegistry (the plugin system)
  DesignSystem/   Theme (colors/fonts) + reusable components (Panel, ActionButton, StatusPill)
  Tools/
    BluetoothMic/ The first tool (model + view + CoreAudio + IOBluetooth)
Resources/        Info.plist + entitlements
scripts/          build_dmg.sh, make_icon.swift
```

---

## How to add a new tool

1. Create `Sources/MyTools/Tools/<YourTool>/<YourTool>Tool.swift`:

   ```swift
   import SwiftUI

   @MainActor
   final class HelloTool: Tool {
       let id = "hello"                 // unique, stable
       let name = "Hello"
       let tagline = "What this tool does in one line."
       let symbol = "sparkles"          // any SF Symbol
       func makeView() -> AnyView { AnyView(Text("Hi").padding()) }
   }
   ```

2. Register it in `Sources/MyTools/Core/ToolRegistry.swift`:

   ```swift
   r.register(HelloTool())
   ```

3. Rebuild. It appears automatically in the sidebar with an index number.

Use `Panel`, `ActionButton`, `StatusPill` from the design system to stay
visually consistent. That's it — no UI wiring, no navigation code.

---

## Permissions

On first launch macOS will ask for **Bluetooth** and **microphone/audio**
access (declared in `Resources/Info.plist`). Approve both for the
Bluetooth → Mic tool to work. The app is ad-hoc signed, so on first open use
**right-click → Open** (or `xattr -dr com.apple.quarantine "/Applications/My Tools.app"`).
