import SwiftUI

/// A titled panel used to group controls inside a tool view.
struct Panel<Content: View>: View {
    let title: String
    var note: String? = nil
    @ViewBuilder var content: Content

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(alignment: .firstTextBaseline, spacing: 8) {
                Text(title.uppercased())
                    .font(.mono(11, .semibold))
                    .tracking(1.4)
                    .foregroundStyle(Theme.inkSoft)
                Rectangle().fill(Theme.hairline).frame(height: 1)
                if let note {
                    Text(note).font(.mono(10)).foregroundStyle(Theme.inkFaint)
                }
            }
            content
        }
        .padding(20)
        .background(Theme.paperRaised, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 12, style: .continuous)
                .strokeBorder(Theme.hairline, lineWidth: 1)
        )
    }
}

/// Primary / ghost button with consistent feel.
struct ActionButton: View {
    enum Kind { case primary, ghost }
    let title: String
    var kind: Kind = .primary
    var icon: String? = nil
    let action: () -> Void
    @State private var hovering = false

    private var fillColor: Color {
        kind == .primary
            ? Theme.accent.opacity(hovering ? 0.9 : 1)
            : Theme.paperSunken.opacity(hovering ? 1 : 0.6)
    }

    var body: some View {
        Button(action: action) {
            HStack(spacing: 7) {
                if let icon { Image(systemName: icon) }
                Text(title).font(.system(size: 13, weight: .medium))
            }
            .padding(.horizontal, 16).padding(.vertical, 9)
            .foregroundStyle(kind == .primary ? Color.white : Theme.ink)
            .background(fillColor, in: RoundedRectangle(cornerRadius: 9, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 9, style: .continuous)
                    .strokeBorder(kind == .ghost ? Theme.hairline : .clear, lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
        .onHover { hovering = $0 }
        .animation(.easeOut(duration: 0.15), value: hovering)
    }
}

/// Small status pill.
struct StatusPill: View {
    let text: String
    let color: Color
    var body: some View {
        HStack(spacing: 6) {
            Circle().fill(color).frame(width: 7, height: 7)
            Text(text).font(.mono(11, .medium)).foregroundStyle(Theme.ink)
        }
        .padding(.horizontal, 10).padding(.vertical, 5)
        .background(color.opacity(0.12), in: Capsule())
    }
}
