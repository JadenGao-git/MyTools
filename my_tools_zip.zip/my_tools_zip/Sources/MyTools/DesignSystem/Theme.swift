import SwiftUI

/// Editorial "tool workshop" palette: warm paper + ink, vermillion accent.
/// Tinted neutrals (never pure black/white), adapts to light & dark.
enum Theme {
    // Accent
    static let accent      = Color(hex: 0xE2532B)   // vermillion
    static let accentSoft  = Color(hex: 0xE2532B).opacity(0.12)

    // Paper (backgrounds) — adaptive
    static let paper       = Color.adaptive(light: 0xF4F1EA, dark: 0x1A1916)
    static let paperRaised = Color.adaptive(light: 0xFBF9F4, dark: 0x232220)
    static let paperSunken = Color.adaptive(light: 0xEAE6DC, dark: 0x141311)

    // Ink (text) — warm, never #000
    static let ink         = Color.adaptive(light: 0x23201A, dark: 0xEDE9DF)
    static let inkSoft     = Color.adaptive(light: 0x6B655A, dark: 0x9A9488)
    static let inkFaint    = Color.adaptive(light: 0x9A9488, dark: 0x615C53)

    static let hairline    = Color.adaptive(light: 0xD8D2C6, dark: 0x33312D)

    // Status
    static let ok          = Color(hex: 0x4E7A4A)
    static let warn        = Color(hex: 0xB8862E)
}

extension Color {
    init(hex: UInt32, alpha: Double = 1) {
        self.init(.sRGB,
                  red:   Double((hex >> 16) & 0xFF) / 255,
                  green: Double((hex >> 8)  & 0xFF) / 255,
                  blue:  Double(hex & 0xFF)        / 255,
                  opacity: alpha)
    }
    static func adaptive(light: UInt32, dark: UInt32) -> Color {
        Color(nsColor: NSColor(name: nil) { appearance in
            let isDark = appearance.bestMatch(from: [.darkAqua, .aqua]) == .darkAqua
            let v = isDark ? dark : light
            return NSColor(srgbRed: Double((v >> 16) & 0xFF)/255,
                           green:   Double((v >> 8)  & 0xFF)/255,
                           blue:    Double(v & 0xFF)/255,
                           alpha: 1)
        })
    }
}

/// Typography — system New York (serif) for display, default sans for body.
extension Font {
    static func display(_ size: CGFloat, _ weight: Font.Weight = .semibold) -> Font {
        .system(size: size, weight: weight, design: .serif)
    }
    static func mono(_ size: CGFloat, _ weight: Font.Weight = .regular) -> Font {
        .system(size: size, weight: weight, design: .monospaced)
    }
}
