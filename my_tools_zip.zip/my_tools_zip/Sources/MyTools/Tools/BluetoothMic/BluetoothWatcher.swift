import Foundation
import IOBluetooth

/// Watches for Bluetooth device connections (event-driven, no polling).
///
/// IMPORTANT: On macOS 26 IOBluetooth delivers its notifications on a private
/// background dispatch queue (com.apple.bluetooth.iobluetooth.coordinatorQueue),
/// NOT on the main run loop. Under Swift 6 strict concurrency, marking this class
/// @MainActor makes the @objc callbacks assert they are running on the main
/// executor — which they are not — and the process traps (EXC_BREAKPOINT).
///
/// Therefore the class is *not* actor-isolated. The @objc callbacks run on
/// whatever queue IOBluetooth uses, extract only Sendable String values from
/// the device, and then hop to the main actor to invoke the consumer closures.
final class BluetoothWatcher: NSObject {
    /// Invoked on the main actor when a device connects.
    var onConnect: (@MainActor (String, String) -> Void)?
    /// Invoked on the main actor when a device disconnects.
    var onDisconnect: (@MainActor (String, String) -> Void)?

    private var connectNotification: IOBluetoothUserNotification?

    func start() {
        for case let dev as IOBluetoothDevice in (IOBluetoothDevice.pairedDevices() ?? []) {
            if dev.isConnected() { handleConnected(dev) }
        }
        connectNotification = IOBluetoothDevice
            .register(forConnectNotifications: self,
                      selector: #selector(deviceConnected(_:device:)))
    }

    func stop() {
        connectNotification?.unregister()
        connectNotification = nil
    }

    func connectedDeviceNames() -> [String] {
        var names: [String] = []
        for case let dev as IOBluetoothDevice in (IOBluetoothDevice.pairedDevices() ?? [])
        where dev.isConnected() {
            names.append(dev.name ?? (dev.addressString ?? "Unknown"))
        }
        return names
    }

    @objc private func deviceConnected(_ note: IOBluetoothUserNotification,
                                       device: IOBluetoothDevice) {
        handleConnected(device)
    }

    private func handleConnected(_ device: IOBluetoothDevice) {
        let name = device.name ?? (device.addressString ?? "Unknown")
        let addr = device.addressString ?? ""
        device.register(forDisconnectNotification: self,
                        selector: #selector(deviceDisconnected(_:device:)))
        let handler = onConnect
        Task { @MainActor in handler?(name, addr) }
    }

    @objc private func deviceDisconnected(_ note: IOBluetoothUserNotification,
                                          device: IOBluetoothDevice) {
        note.unregister()
        let name = device.name ?? (device.addressString ?? "Unknown")
        let addr = device.addressString ?? ""
        let handler = onDisconnect
        Task { @MainActor in handler?(name, addr) }
    }
}
