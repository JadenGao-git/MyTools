import SwiftUI
import Combine
import CoreAudio

@MainActor
final class BluetoothMicModel: ObservableObject {
    @Published var isEnabled = false
    @Published var targetDeviceName: String = ""          // keyword to match
    @Published var inputDevices: [AudioInputDevice] = []
    @Published var selectedMicID: AudioDeviceID?           // device to switch to
    @Published var currentInputName: String = "—"
    @Published var connectedBT: [String] = []
    @Published var log: [LogLine] = []

    struct LogLine: Identifiable { let id = UUID(); let time: String; let text: String }

    private let watcher = BluetoothWatcher()
    private let defaults = UserDefaults.standard
    private let kEnabled = "btmic.enabled"
    private let kTarget  = "btmic.target"
    private let kMicName = "btmic.micName"

    /// Re-apply schedule (seconds after a connect event). macOS may grab the
    /// input for the Bluetooth device 1–3s AFTER the connect notification, so a
    /// single immediate switch loses the race. We re-assert several times and
    /// verify the change actually stuck.
    private let enforceDelays: [Double] = [0, 0.8, 1.6, 2.6, 4.0, 6.0]
    private var enforceGeneration = 0

    init() {
        targetDeviceName = defaults.string(forKey: kTarget) ?? ""
        refreshDevices()
        // restore saved mic by name
        if let savedMic = defaults.string(forKey: kMicName) {
            selectedMicID = inputDevices.first(where: { $0.name == savedMic })?.id
        }
        if selectedMicID == nil { selectedMicID = AudioInputManager.builtInMic()?.id }
        refreshCurrentInput()

        watcher.onConnect = { [weak self] name, _ in self?.handleConnect(name) }
        watcher.onDisconnect = { [weak self] name, _ in
            self?.append("已断开：\(name)")
            self?.refreshConnected()
        }
        watcher.start()
        refreshConnected()

        if defaults.bool(forKey: kEnabled) { isEnabled = true }
    }

    func refreshDevices() {
        inputDevices = AudioInputManager.inputDevices()
        if selectedMicID == nil { selectedMicID = AudioInputManager.builtInMic()?.id }
    }

    func refreshCurrentInput() {
        if let id = AudioInputManager.currentDefaultInput(),
           let d = inputDevices.first(where: { $0.id == id }) {
            currentInputName = d.name
        } else { currentInputName = "—" }
    }

    func refreshConnected() { connectedBT = watcher.connectedDeviceNames() }

    /// 下拉可选项：当前已连接的蓝牙设备；若已保存的目标当前未连接，也并入列表。
    var triggerOptions: [String] {
        var list = connectedBT
        let saved = targetDeviceName.trimmingCharacters(in: .whitespaces)
        if !saved.isEmpty && !list.contains(saved) { list.append(saved) }
        return list
    }

    func selectTarget(_ name: String) {
        targetDeviceName = name
        defaults.set(name, forKey: kTarget)
        append("已选择监听设备「\(name)」。")
    }

    func setEnabled(_ on: Bool) {
        isEnabled = on
        defaults.set(on, forKey: kEnabled)
        append(on ? "已启用监听。" : "已暂停监听。")
    }

    func saveTarget() {
        defaults.set(targetDeviceName, forKey: kTarget)
        append("已将目标设为「\(targetDeviceName)」。")
    }

    func selectMic(_ id: AudioDeviceID) {
        selectedMicID = id
        if let name = inputDevices.first(where: { $0.id == id })?.name {
            defaults.set(name, forKey: kMicName)
        }
    }

    /// Resolve the target device ID fresh each time (IDs can change when devices
    /// come and go). Prefer the user's saved choice; fall back to built-in mic.
    private func resolveTargetMic() -> (id: AudioDeviceID, name: String)? {
        refreshDevices()
        if let id = selectedMicID,
           let d = inputDevices.first(where: { $0.id == id }) {
            return (d.id, d.name)
        }
        // saved selection may be stale → re-resolve by saved name, then built-in
        if let savedName = defaults.string(forKey: kMicName),
           let d = inputDevices.first(where: { $0.name == savedName }) {
            selectedMicID = d.id
            return (d.id, d.name)
        }
        if let d = AudioInputManager.builtInMic() {
            selectedMicID = d.id
            return (d.id, d.name)
        }
        return nil
    }

    /// Apply the switch once. Returns true only if, after setting, the system's
    /// actual default input really equals the target.
    @discardableResult
    private func applyOnce(_ target: AudioDeviceID) -> Bool {
        _ = AudioInputManager.setDefaultInput(target)
        return AudioInputManager.currentDefaultInput() == target
    }

    /// Manual one-shot switch (the "Switch now" button).
    func switchNow() {
        guard let mic = resolveTargetMic() else { append("未选择麦克风。"); return }
        if applyOnce(mic.id) {
            append("已将输入切换到 \(mic.name)。")
        } else {
            append("切换失败（CoreAudio 拒绝或被系统抢占）。")
        }
        refreshCurrentInput()
    }

    /// Persistent switch used after a Bluetooth connect: re-assert the target a
    /// few times over several seconds, because macOS often grabs the input for
    /// the just-connected device slightly later, overriding a single switch.
    private func enforceSwitch(reason: String) {
        guard let mic = resolveTargetMic() else { append("未选择麦克风。"); return }
        enforceGeneration += 1
        let gen = enforceGeneration
        let delays = enforceDelays
        append("\(reason) → 正在切换并锁定到 \(mic.name)。")

        Task { @MainActor in
            var confirmed = false
            for (i, delay) in delays.enumerated() {
                if gen != self.enforceGeneration { return }   // superseded by newer event
                if delay > 0 {
                    try? await Task.sleep(nanoseconds: UInt64(delay * 1_000_000_000))
                    if gen != self.enforceGeneration { return }
                }
                // re-resolve in case IDs changed mid-flight
                guard let m = self.resolveTargetMic() else { continue }
                let already = AudioInputManager.currentDefaultInput() == m.id
                if already {
                    if !confirmed {
                        self.append("输入已锁定为 \(m.name)。")
                        confirmed = true
                    }
                    // keep watching a couple more rounds to catch a late override
                    if i >= delays.count - 1 { break }
                    continue
                }
                let ok = self.applyOnce(m.id)
                self.refreshCurrentInput()
                if ok {
                    self.append("已切换到 \(m.name)（第 \(i + 1) 次尝试生效）。")
                    confirmed = true
                }
            }
            if !confirmed {
                self.append("多次尝试后仍未能锁定到内置麦克风，请检查权限或手动点「立即切换」。")
            }
            self.refreshCurrentInput()
        }
    }

    private func handleConnect(_ name: String) {
        refreshConnected()
        guard isEnabled else { return }
        let key = targetDeviceName.trimmingCharacters(in: .whitespaces)
        guard !key.isEmpty else { return }          // 未选择设备则不触发
        guard name.localizedCaseInsensitiveContains(key) else { return }
        enforceSwitch(reason: "已连接：\(name)")
    }

    private func append(_ text: String) {
        let f = DateFormatter(); f.dateFormat = "HH:mm:ss"
        log.insert(LogLine(time: f.string(from: Date()), text: text), at: 0)
        if log.count > 40 { log.removeLast() }
    }
}
