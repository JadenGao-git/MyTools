import SwiftUI

@MainActor
final class BluetoothMicTool: Tool {
    let id = "bluetooth-mic"
    let name = "蓝牙 → 麦克风"
    let tagline = "当指定的蓝牙设备连接时，自动把声音输入切回内置麦克风。"
    let symbol = "mic.badge.plus"

    let model = BluetoothMicModel()

    func makeView() -> AnyView { AnyView(BluetoothMicView(model: model)) }

    // MARK: - Background capability
    var supportsBackground: Bool { true }
    var isBackgroundActive: Bool { model.isEnabled }
    func startBackground() { model.setEnabled(true) }
    func stopBackground() { model.setEnabled(false) }
}

struct BluetoothMicView: View {
    @ObservedObject var model: BluetoothMicModel
    @EnvironmentObject var registry: ToolRegistry
    private let toolID = "bluetooth-mic"

    var body: some View {
        VStack(alignment: .leading, spacing: 22) {

            // Status strip
            HStack(spacing: 14) {
                StatusPill(text: model.isEnabled ? "运行中" : "已暂停",
                           color: model.isEnabled ? Theme.ok : Theme.warn)
                Text("当前输入：\(model.currentInputName)")
                    .font(.mono(12)).foregroundStyle(Theme.inkSoft)
                Spacer()
                Toggle("", isOn: Binding(get: { model.isEnabled },
                                         set: { model.setEnabled($0) }))
                    .toggleStyle(.switch).labelsHidden().tint(Theme.accent)
            }

            // 后台 & 开机自启
            Panel(title: "后台运行", note: "menu bar") {
                VStack(alignment: .leading, spacing: 12) {
                    Toggle(isOn: Binding(
                        get: { _ = registry.backgroundTick; return registry.isAutostart(toolID) },
                        set: { registry.setAutostart(toolID, $0) }
                    )) {
                        VStack(alignment: .leading, spacing: 2) {
                            Text("开机时自动启动此工具")
                                .font(.system(size: 13, weight: .medium))
                                .foregroundStyle(Theme.ink)
                            Text("开启后会一并启用「开机自动启动 My Tools」，登录即在菜单栏后台监听。")
                                .font(.system(size: 11)).foregroundStyle(Theme.inkSoft)
                        }
                    }
                    .toggleStyle(.switch).tint(Theme.accent)

                    Text("关闭主窗口后，程序仍会驻留菜单栏继续监听；从菜单栏「退出」才会完全关闭。")
                        .font(.mono(10)).foregroundStyle(Theme.inkFaint)
                }
            }

            // Trigger
            Panel(title: "触发条件", note: "蓝牙设备") {
                VStack(alignment: .leading, spacing: 10) {
                    Text("选择要监听的蓝牙设备")
                        .font(.system(size: 12)).foregroundStyle(Theme.inkSoft)
                    if model.triggerOptions.isEmpty {
                        HStack {
                            Text("未检测到已连接的蓝牙设备")
                                .font(.system(size: 13)).foregroundStyle(Theme.inkFaint)
                            Spacer()
                            ActionButton(title: "刷新", kind: .ghost, icon: "arrow.clockwise") {
                                model.refreshConnected()
                            }
                        }
                    } else {
                        HStack(spacing: 10) {
                            Picker("", selection: Binding(
                                get: { model.targetDeviceName },
                                set: { model.selectTarget($0) })) {
                                if model.targetDeviceName.isEmpty {
                                    Text("请选择…").tag("")
                                }
                                ForEach(model.triggerOptions, id: \.self) { name in
                                    Text(name).tag(name)
                                }
                            }
                            .labelsHidden().pickerStyle(.menu).tint(Theme.ink)
                            ActionButton(title: "刷新", kind: .ghost, icon: "arrow.clockwise") {
                                model.refreshConnected()
                            }
                        }
                    }
                }
            }

            // Action target
            Panel(title: "执行动作", note: "切换输入到") {
                VStack(alignment: .leading, spacing: 12) {
                    Picker("", selection: Binding(
                        get: { model.selectedMicID ?? 0 },
                        set: { model.selectMic($0) })) {
                        ForEach(model.inputDevices) { d in
                            Text(d.isBuiltIn ? "\(d.name)  · 内置" : d.name).tag(d.id)
                        }
                    }
                    .labelsHidden().pickerStyle(.menu).tint(Theme.ink)

                    HStack(spacing: 10) {
                        ActionButton(title: "立即切换", icon: "arrow.right.circle") {
                            model.switchNow()
                        }
                        ActionButton(title: "刷新设备", kind: .ghost, icon: "arrow.clockwise") {
                            model.refreshDevices(); model.refreshCurrentInput(); model.refreshConnected()
                        }
                    }
                }
            }

            // Activity log
            Panel(title: "活动记录") {
                if model.log.isEmpty {
                    Text("暂无事件。连接你的蓝牙设备后会显示在这里。")
                        .font(.system(size: 12)).foregroundStyle(Theme.inkFaint)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.vertical, 6)
                } else {
                    VStack(alignment: .leading, spacing: 6) {
                        ForEach(model.log) { line in
                            HStack(alignment: .top, spacing: 10) {
                                Text(line.time).font(.mono(11)).foregroundStyle(Theme.inkFaint)
                                Text(line.text).font(.mono(11)).foregroundStyle(Theme.ink)
                            }
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
            }
        }
    }
}
