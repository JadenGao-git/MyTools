import Foundation
import CoreAudio
import AudioToolbox

struct AudioInputDevice: Identifiable, Hashable {
    let id: AudioDeviceID
    let name: String
    let isBuiltIn: Bool
}

/// Thin CoreAudio wrapper for enumerating input devices and switching the
/// system default input device.
enum AudioInputManager {

    static func inputDevices() -> [AudioInputDevice] {
        var result: [AudioInputDevice] = []
        for dev in allDeviceIDs() where hasInputStreams(dev) {
            let name = deviceName(dev) ?? "Unknown"
            result.append(AudioInputDevice(id: dev, name: name,
                                           isBuiltIn: isBuiltIn(dev)))
        }
        return result
    }

    static func currentDefaultInput() -> AudioDeviceID? {
        var addr = AudioObjectPropertyAddress(
            mSelector: kAudioHardwarePropertyDefaultInputDevice,
            mScope: kAudioObjectPropertyScopeGlobal,
            mElement: kAudioObjectPropertyElementMain)
        var dev = AudioDeviceID(0)
        var size = UInt32(MemoryLayout<AudioDeviceID>.size)
        let st = AudioObjectGetPropertyData(AudioObjectID(kAudioObjectSystemObject),
                                            &addr, 0, nil, &size, &dev)
        return st == noErr ? dev : nil
    }

    @discardableResult
    static func setDefaultInput(_ device: AudioDeviceID) -> Bool {
        var addr = AudioObjectPropertyAddress(
            mSelector: kAudioHardwarePropertyDefaultInputDevice,
            mScope: kAudioObjectPropertyScopeGlobal,
            mElement: kAudioObjectPropertyElementMain)
        var dev = device
        let size = UInt32(MemoryLayout<AudioDeviceID>.size)
        let st = AudioObjectSetPropertyData(AudioObjectID(kAudioObjectSystemObject),
                                            &addr, 0, nil, size, &dev)
        return st == noErr
    }

    /// Best-effort pick of the internal microphone.
    static func builtInMic() -> AudioInputDevice? {
        let inputs = inputDevices()
        return inputs.first(where: { $0.isBuiltIn })
            ?? inputs.first(where: { $0.name.localizedCaseInsensitiveContains("MacBook") })
            ?? inputs.first(where: { $0.name.localizedCaseInsensitiveContains("Built-in")
                                   || $0.name.localizedCaseInsensitiveContains("Internal") })
    }

    // MARK: - Private

    private static func allDeviceIDs() -> [AudioDeviceID] {
        var addr = AudioObjectPropertyAddress(
            mSelector: kAudioHardwarePropertyDevices,
            mScope: kAudioObjectPropertyScopeGlobal,
            mElement: kAudioObjectPropertyElementMain)
        var size = UInt32(0)
        guard AudioObjectGetPropertyDataSize(AudioObjectID(kAudioObjectSystemObject),
                                             &addr, 0, nil, &size) == noErr else { return [] }
        let count = Int(size) / MemoryLayout<AudioDeviceID>.size
        var ids = [AudioDeviceID](repeating: 0, count: count)
        guard AudioObjectGetPropertyData(AudioObjectID(kAudioObjectSystemObject),
                                         &addr, 0, nil, &size, &ids) == noErr else { return [] }
        return ids
    }

    private static func hasInputStreams(_ dev: AudioDeviceID) -> Bool {
        var addr = AudioObjectPropertyAddress(
            mSelector: kAudioDevicePropertyStreamConfiguration,
            mScope: kAudioObjectPropertyScopeInput,
            mElement: kAudioObjectPropertyElementMain)
        var size = UInt32(0)
        guard AudioObjectGetPropertyDataSize(dev, &addr, 0, nil, &size) == noErr, size > 0
        else { return false }
        let bufList = UnsafeMutableRawPointer.allocate(byteCount: Int(size),
                                                       alignment: MemoryLayout<AudioBufferList>.alignment)
        defer { bufList.deallocate() }
        guard AudioObjectGetPropertyData(dev, &addr, 0, nil, &size, bufList) == noErr
        else { return false }
        let abl = UnsafeMutableAudioBufferListPointer(bufList.assumingMemoryBound(to: AudioBufferList.self))
        for b in abl where b.mNumberChannels > 0 { return true }
        return false
    }

    private static func deviceName(_ dev: AudioDeviceID) -> String? {
        var addr = AudioObjectPropertyAddress(
            mSelector: kAudioObjectPropertyName,
            mScope: kAudioObjectPropertyScopeGlobal,
            mElement: kAudioObjectPropertyElementMain)
        var name: CFString = "" as CFString
        var size = UInt32(MemoryLayout<CFString>.size)
        let st = AudioObjectGetPropertyData(dev, &addr, 0, nil, &size, &name)
        return st == noErr ? (name as String) : nil
    }

    private static func isBuiltIn(_ dev: AudioDeviceID) -> Bool {
        var addr = AudioObjectPropertyAddress(
            mSelector: kAudioDevicePropertyTransportType,
            mScope: kAudioObjectPropertyScopeGlobal,
            mElement: kAudioObjectPropertyElementMain)
        var transport = UInt32(0)
        var size = UInt32(MemoryLayout<UInt32>.size)
        let st = AudioObjectGetPropertyData(dev, &addr, 0, nil, &size, &transport)
        return st == noErr && transport == kAudioDeviceTransportTypeBuiltIn
    }
}
