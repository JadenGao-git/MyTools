import SwiftUI
import AppKit

/// The dropdown shown from the menu bar icon.
struct MenuBarContent: View {
    @EnvironmentObject var registry: ToolRegistry
    @Environment(\.openWindow) private var openWindow

    var body: some View {
        // Per-tool background toggles
        ForEach(registry.tools, id: \.id) { tool in
            if tool.supportsBackground {
                Toggle(isOn: Binding(
                    get: { _ = registry.backgroundTick; return tool.isBackgroundActive },
                    set: { _ in registry.toggleBackground(tool.id) }
                )) {
                    Text("\(tool.name)：后台监听")
                }
            }
        }

        Divider()

        Toggle(isOn: Binding(
            get: { LaunchAtLogin.isEnabled },
            set: { LaunchAtLogin.set($0) }
        )) {
            Text("开机自动启动 My Tools")
        }

        Divider()

        Button("打开主界面") {
            NSApp.setActivationPolicy(.regular)
            NSApp.activate(ignoringOtherApps: true)
            openWindow(id: "main")
        }

        Button("退出 My Tools") {
            NSApp.terminate(nil)
        }
        .keyboardShortcut("q")
    }
}
