import SwiftUI

struct RootView: View {
    @EnvironmentObject var registry: ToolRegistry
    @State private var selection: String?

    var body: some View {
        HStack(spacing: 0) {
            Sidebar(selection: $selection)
                .frame(width: 248)
            Rectangle().fill(Theme.hairline).frame(width: 1)
            DetailPane(selection: selection)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .background(Theme.paper)
        .onAppear { if selection == nil { selection = registry.tools.first?.id } }
        .preferredColorScheme(nil)
    }
}

private struct Sidebar: View {
    @EnvironmentObject var registry: ToolRegistry
    @Binding var selection: String?

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            // Masthead
            VStack(alignment: .leading, spacing: 2) {
                Text("我的").font(.display(26, .bold)).foregroundStyle(Theme.ink)
                HStack(spacing: 6) {
                    Text("工具箱").font(.display(26, .bold)).foregroundStyle(Theme.accent)
                    Rectangle().fill(Theme.accent).frame(width: 18, height: 3).offset(y: -4)
                }
            }
            .padding(.horizontal, 22).padding(.top, 30).padding(.bottom, 4)

            Text("个人工具集")
                .font(.mono(10)).tracking(1).foregroundStyle(Theme.inkFaint)
                .padding(.horizontal, 22).padding(.bottom, 22)

            // Index label
            HStack {
                Text("目录").font(.mono(10, .semibold)).tracking(2).foregroundStyle(Theme.inkFaint)
                Spacer()
                Text(String(format: "%02d", registry.tools.count))
                    .font(.mono(10, .semibold)).foregroundStyle(Theme.inkFaint)
            }
            .padding(.horizontal, 22).padding(.bottom, 10)

            // Tool list
            ScrollView {
                VStack(spacing: 2) {
                    ForEach(Array(registry.tools.enumerated()), id: \.element.id) { idx, tool in
                        SidebarRow(index: idx + 1, tool: tool,
                                   isSelected: selection == tool.id) {
                            selection = tool.id
                        }
                    }
                }
                .padding(.horizontal, 12)
            }

            Spacer()
            Divider().overlay(Theme.hairline)
            Text("v1.0 · 在 ToolRegistry.swift 中扩展")
                .font(.mono(9)).foregroundStyle(Theme.inkFaint)
                .padding(.horizontal, 22).padding(.vertical, 12)
        }
        .frame(maxHeight: .infinity, alignment: .top)
        .background(Theme.paperSunken)
    }
}

private struct SidebarRow: View {
    let index: Int
    let tool: any Tool
    let isSelected: Bool
    let action: () -> Void
    @State private var hovering = false

    var body: some View {
        Button(action: action) {
            HStack(spacing: 12) {
                Text(String(format: "%02d", index))
                    .font(.mono(11, .medium))
                    .foregroundStyle(isSelected ? Theme.accent : Theme.inkFaint)
                Image(systemName: tool.symbol)
                    .font(.system(size: 13))
                    .frame(width: 18)
                    .foregroundStyle(isSelected ? Theme.ink : Theme.inkSoft)
                Text(tool.name)
                    .font(.system(size: 13, weight: isSelected ? .semibold : .regular))
                    .foregroundStyle(isSelected ? Theme.ink : Theme.inkSoft)
                Spacer()
            }
            .padding(.horizontal, 12).padding(.vertical, 9)
            .background(
                ZStack(alignment: .leading) {
                    RoundedRectangle(cornerRadius: 8, style: .continuous)
                        .fill(isSelected ? Theme.paperRaised : (hovering ? Theme.paperRaised.opacity(0.5) : .clear))
                    if isSelected {
                        Rectangle().fill(Theme.accent).frame(width: 3)
                            .clipShape(RoundedRectangle(cornerRadius: 2))
                    }
                }
            )
        }
        .buttonStyle(.plain)
        .onHover { hovering = $0 }
        .animation(.easeOut(duration: 0.12), value: hovering)
    }
}

private struct DetailPane: View {
    @EnvironmentObject var registry: ToolRegistry
    let selection: String?

    var body: some View {
        if let id = selection, let tool = registry.tools.first(where: { $0.id == id }) {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    // Header
                    VStack(alignment: .leading, spacing: 8) {
                        Text(tool.name)
                            .font(.display(34, .bold))
                            .foregroundStyle(Theme.ink)
                        Text(tool.tagline)
                            .font(.system(size: 15))
                            .foregroundStyle(Theme.inkSoft)
                        Rectangle().fill(Theme.accent).frame(width: 46, height: 3).padding(.top, 4)
                    }
                    tool.makeView()
                }
                .padding(.horizontal, 40).padding(.top, 44).padding(.bottom, 40)
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .background(Theme.paper)
        } else {
            VStack { Text("请选择左侧工具").font(.display(20)).foregroundStyle(Theme.inkSoft) }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(Theme.paper)
        }
    }
}
