import SwiftUI
import AppKit

@main
struct MyToolsApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) private var appDelegate
    @StateObject private var registry = ToolRegistry.shared

    var body: some Scene {
        // Main configuration window
        Window("My Tools", id: "main") {
            RootView()
                .environmentObject(registry)
                .frame(minWidth: 820, minHeight: 560)
        }
        .windowStyle(.hiddenTitleBar)
        .windowResizability(.contentMinSize)

        // Menu bar resident
        MenuBarExtra("My Tools", systemImage: "wrench.adjustable") {
            MenuBarContent()
                .environmentObject(registry)
        }
        .menuBarExtraStyle(.menu)
    }
}

/// Keeps the app alive when the window closes (menu-bar resident),
/// and starts autostart tools at launch.
final class AppDelegate: NSObject, NSApplicationDelegate {
    func applicationDidFinishLaunching(_ notification: Notification) {
        // Start any tools the user marked as "launch at login".
        Task { @MainActor in
            ToolRegistry.shared.activateAutostartTools()
        }
    }

    // Closing the last window should NOT quit the app — it lives in the menu bar.
    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool {
        false
    }
}
