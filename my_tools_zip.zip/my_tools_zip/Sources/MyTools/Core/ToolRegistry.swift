import SwiftUI

/// Holds every registered tool. Single source of truth for the sidebar,
/// and manages per-tool "launch at login" (background autostart) preferences.
@MainActor
final class ToolRegistry: ObservableObject {
    static let shared = ToolRegistry.bootstrap()

    @Published private(set) var tools: [any Tool] = []
    /// Bumped whenever a tool's background state changes, so views refresh.
    @Published var backgroundTick = 0

    private let defaults = UserDefaults.standard
    private func autostartKey(_ id: String) -> String { "tool.autostart.\(id)" }

    func register(_ tool: any Tool) {
        guard !tools.contains(where: { $0.id == tool.id }) else { return }
        tools.append(tool)
    }

    func tool(id: String) -> (any Tool)? { tools.first { $0.id == id } }

    // MARK: - Per-tool autostart preference

    func isAutostart(_ id: String) -> Bool { defaults.bool(forKey: autostartKey(id)) }

    func setAutostart(_ id: String, _ on: Bool) {
        defaults.set(on, forKey: autostartKey(id))
        // Ensure overall app autostart is on if ANY tool wants to autostart,
        // so the app is actually relaunched at login to run the background work.
        if on { LaunchAtLogin.set(true) }
        else if !tools.contains(where: { isAutostart($0.id) }) {
            // no tool needs autostart anymore — leave app autostart as user set it
        }
        if on { tool(id: id)?.startBackground() }
        backgroundTick += 1
    }

    /// Called once at launch: start background work for every tool whose
    /// autostart preference is on.
    func activateAutostartTools() {
        for t in tools where t.supportsBackground && isAutostart(t.id) {
            t.startBackground()
        }
        backgroundTick += 1
    }

    /// Any tool currently running in the background?
    var anyBackgroundActive: Bool {
        tools.contains { $0.supportsBackground && $0.isBackgroundActive }
    }

    func toggleBackground(_ id: String) {
        guard let t = tool(id: id), t.supportsBackground else { return }
        if t.isBackgroundActive { t.stopBackground() } else { t.startBackground() }
        backgroundTick += 1
    }

    /// Register all built-in tools here. This is the ONE place you edit
    /// when adding a new mini-tool.
    static func bootstrap() -> ToolRegistry {
        let r = ToolRegistry()
        r.register(BluetoothMicTool())
        // r.register(YourNextTool())   <-- future tools go here
        return r
    }
}
