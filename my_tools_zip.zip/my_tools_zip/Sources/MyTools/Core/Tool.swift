import SwiftUI

/// A plugin. To add a new tool: create a type conforming to `Tool`,
/// then register it in `ToolRegistry.bootstrap()`. Nothing else to touch.
@MainActor
protocol Tool: AnyObject, Identifiable {
    var id: String { get }            // stable, unique (e.g. "bluetooth-mic")
    var name: String { get }          // sidebar title
    var tagline: String { get }       // one-line description
    var symbol: String { get }        // SF Symbol name
    @ViewBuilder func makeView() -> AnyView

    // --- Optional background capability ---
    // A tool may run work in the background (independent of its window).
    // Default implementations below make these optional for simple tools.
    var supportsBackground: Bool { get }   // does this tool have a background mode?
    var isBackgroundActive: Bool { get }   // is it currently running?
    func startBackground()                 // begin background work
    func stopBackground()                  // stop background work
}

extension Tool {
    var supportsBackground: Bool { false }
    var isBackgroundActive: Bool { false }
    func startBackground() {}
    func stopBackground() {}
}
