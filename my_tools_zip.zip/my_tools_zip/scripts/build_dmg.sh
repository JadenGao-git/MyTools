#!/usr/bin/env bash
# Build "My Tools.app" (release) and package "My Tools.dmg".
# Usage: bash scripts/build_dmg.sh   (run from the project root)
set -euo pipefail
cd "$(dirname "$0")/.."

APP_NAME="My Tools"
EXEC_NAME="MyTools"
BUILD_DIR="build"
APP="$BUILD_DIR/$APP_NAME.app"
DMG="$BUILD_DIR/$APP_NAME.dmg"
RAW="$BUILD_DIR/raw.dmg"
SINK="$BUILD_DIR/.sink"

echo "==> 1/6 Compiling (release)..."
swift build -c release --disable-sandbox
BIN="$(swift build -c release --disable-sandbox --show-bin-path)/$EXEC_NAME"

echo "==> 2/6 Preparing icon..."
# 优先使用自定义图标 Resources/AppIcon.png（建议 1024x1024 PNG）；
# 没有则用脚本生成的默认图标。
if [ -f Resources/AppIcon.png ]; then
  sips -s format png -z 1024 1024 Resources/AppIcon.png --out build/icon_1024.png >/dev/null
  echo "    使用自定义图标 Resources/AppIcon.png"
else
  [ -f build/icon_1024.png ] || swift scripts/make_icon.swift build/icon_1024.png
  echo "    使用默认生成图标"
fi

echo "==> 3/6 Assembling bundle..."
rm -rf "$APP"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
cp "$BIN" "$APP/Contents/MacOS/$EXEC_NAME"
cp Resources/Info.plist "$APP/Contents/Info.plist"
ICONSET="$BUILD_DIR/AppIcon.iconset"; rm -rf "$ICONSET"; mkdir -p "$ICONSET"
for s in 16 32 64 128 256 512; do
  sips -s format png -z $s $s build/icon_1024.png --out "$ICONSET/icon_${s}x${s}.png" > "$SINK"
  d=$((s*2)); sips -s format png -z $d $d build/icon_1024.png --out "$ICONSET/icon_${s}x${s}@2x.png" > "$SINK"
done
iconutil -c icns "$ICONSET" -o "$APP/Contents/Resources/AppIcon.icns"

echo "==> 4/6 Code signing (ad-hoc)..."
codesign --force --deep --sign - --entitlements Resources/MyTools.entitlements "$APP"
codesign --verify --verbose "$APP"

echo "==> 5/6 Building DMG..."
STAGE="$BUILD_DIR/dmg_stage"; rm -rf "$STAGE"; mkdir -p "$STAGE"
cp -R "$APP" "$STAGE/"; ln -s /Applications "$STAGE/Applications"
rm -f "$DMG" "$RAW"
hdiutil makehybrid -hfs -hfs-volume-name "$APP_NAME" -o "$RAW" "$STAGE" > "$SINK"
hdiutil convert "$RAW" -format UDZO -o "$DMG" > "$SINK"
rm -f "$RAW" "$SINK"; rm -rf "$STAGE"

echo "==> 6/6 Done:"
echo "    $APP"
echo "    $DMG"
