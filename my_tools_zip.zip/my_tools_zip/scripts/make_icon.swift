import AppKit

let size = 1024.0
let img = NSImage(size: NSSize(width: size, height: size))
img.lockFocus()
let ctx = NSGraphicsContext.current!.cgContext

// rounded paper background
let paper = NSColor(srgbRed: 0xF4/255, green: 0xF1/255, blue: 0xEA/255, alpha: 1)
let ink   = NSColor(srgbRed: 0x23/255, green: 0x20/255, blue: 0x1A/255, alpha: 1)
let verm  = NSColor(srgbRed: 0xE2/255, green: 0x53/255, blue: 0x2B/255, alpha: 1)

let r: CGFloat = size * 0.225
let bg = NSBezierPath(roundedRect: NSRect(x: 0, y: 0, width: size, height: size),
                      xRadius: r, yRadius: r)
paper.setFill(); bg.fill()

// thin inner frame
ink.withAlphaComponent(0.12).setStroke()
let frame = NSBezierPath(roundedRect: NSRect(x: 70, y: 70, width: size-140, height: size-140),
                         xRadius: r*0.7, yRadius: r*0.7)
frame.lineWidth = 6; frame.stroke()

// big serif "M"
let para = NSMutableParagraphStyle(); para.alignment = .center
let mAttr: [NSAttributedString.Key: Any] = [
    .font: NSFont(name: "Times New Roman", size: 640) ?? NSFont.systemFont(ofSize: 640, weight: .bold),
    .foregroundColor: ink,
    .paragraphStyle: para
]
let m = NSAttributedString(string: "M", attributes: mAttr)
let ms = m.size()
m.draw(at: NSPoint(x: (size-ms.width)/2, y: (size-ms.height)/2 - 30))

// vermillion accent bar bottom-left + dot
verm.setFill()
NSBezierPath(roundedRect: NSRect(x: 150, y: 165, width: 230, height: 34),
             xRadius: 17, yRadius: 17).fill()
NSBezierPath(ovalIn: NSRect(x: 410, y: 160, width: 44, height: 44)).fill()

img.unlockFocus()

let tiff = img.tiffRepresentation!
let rep = NSBitmapImageRep(data: tiff)!
let png = rep.representation(using: .png, properties: [:])!
try! png.write(to: URL(fileURLWithPath: CommandLine.arguments[1]))
print("icon written")
